#!/bin/bash
sudo docker pull 575439814610.dkr.ecr.eu-west-1.amazonaws.com/users-service-dev:latest
